interface IListModelAngular {
    name: string;
    description: string;
    listId: number;
    due: string;
    state: string;
    owner: string;
}
export default IListModelAngular;