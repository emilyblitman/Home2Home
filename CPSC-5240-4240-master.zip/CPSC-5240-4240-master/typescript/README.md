Prerequisites:
* Install nodeJS server
* Install git

To configure your server run:
* npm install

To start your server run:
* node eServerJsonParams.js

To test the server with the browser navigate to:
* http://localhost/sample1.html

To compile TypeScript files:
* tsc utilities.ts