"use strict";
exports.__esModule = true;
var googleOauth2 = /** @class */ (function () {
    function googleOauth2() {
    }
    //  static id: string = '865451719691-uft2slse60k05d2blk6o3q7lvvak2u2k.apps.googleusercontent.com';
    //  static secret:string = 'yGEyo3l_-OQ51cl8UxHpbIVR';
    googleOauth2.id = '974884334061-f7k65vj8g8dcp4sm1hnp3i6bg51soala.apps.googleusercontent.com';
    googleOauth2.secret = 'd_yCeLvoxgDnxtTa2JX5GpkN';
    return googleOauth2;
}());
exports["default"] = googleOauth2;
