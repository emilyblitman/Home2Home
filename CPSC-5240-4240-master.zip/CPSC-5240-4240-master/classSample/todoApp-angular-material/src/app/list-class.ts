export interface ListClass {
    name: string;
    description: string;
    listId: number;
    due: string;
    state: string;
    owner: string;
    items: string;
}