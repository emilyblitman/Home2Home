export class Lists {
    name: string;
    description: string;
    id: string;
    due: string;
    state: string;
    owner: string;
    items: string;
}