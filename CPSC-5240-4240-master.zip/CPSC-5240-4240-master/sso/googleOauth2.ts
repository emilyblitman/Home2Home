class googleOauth2 {
static id: string = '{Add client ID info from Oauth portal}';
static secret:string = '{Add client secret from Oauth portal}';

}
export default googleOauth2;