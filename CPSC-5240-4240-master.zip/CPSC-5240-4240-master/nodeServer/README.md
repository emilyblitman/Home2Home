This directory contains a very simple node server:
* nServer.js - basic node http server

Make sure you install the node.js server software.  Ensure your path variable contains the execution path of the node.js binary.

To execute the server run one of the following commands:

1. node nServer.js

To test the server, try the following URL on the browser, while the server is running:
* http://localhost:8080/
* http://localhost:8080/index.html
* http://localhost:8080/index2.html
* http://localhost:8080/index3.html